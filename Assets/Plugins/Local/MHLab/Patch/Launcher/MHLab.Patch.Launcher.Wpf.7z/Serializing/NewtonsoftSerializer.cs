﻿using MHLab.Patch.Core.Serializing;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace MHLab.Patch.Launcher.Wpf.Serializing
{
    public sealed class NewtonsoftSerializer : ISerializer
    {
        public string Serialize<TObject>(TObject obj)
        {
            return JsonConvert.SerializeObject(obj, Formatting.Indented, new VersionConverter());
        }

        public TObject Deserialize<TObject>(string data)
        {
            return JsonConvert.DeserializeObject<TObject>(data, new VersionConverter());
        }
    }
}
